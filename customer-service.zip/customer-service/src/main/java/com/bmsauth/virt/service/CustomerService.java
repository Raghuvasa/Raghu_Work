package com.bmsauth.virt.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bmsauth.virt.dto.CustomerDto;
import com.bmsauth.virt.entities.Customer;
import com.bmsauth.virt.exception.CustomerNotFoundException;
import com.bmsauth.virt.mapper.CustomerMapper;
import com.bmsauth.virt.repo.CustomerRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CustomerService {

    private final CustomerRepository customerRepository;
    private final CustomerMapper mapper;
    

    public CustomerDto createCustomer(CustomerDto customer) {
    	
    	Customer customerT = CustomerMapper.toEntity(customer);
         Customer savedCustomer = customerRepository.save(customerT);
         return mapper.toDto(savedCustomer);
    }

    public CustomerDto getCustomerById(Long id) {
         Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found"));
         return mapper.toDto(customer);
    }

    public List<CustomerDto> getAllCustomers() {
         List<Customer> customerList = customerRepository.findAll();
         return mapper.toDtoList(customerList);
    }

    public CustomerDto updateCustomer(Long id, Customer updatedCustomer) {

    	  Customer customer = customerRepository.findById(id)
                  .orElseThrow(() -> new CustomerNotFoundException("Customer not found"));
      

    	  customer.setName(updatedCustomer.getName());
    	  customer.setEmail(updatedCustomer.getEmail());
    	  customer.setPhone(updatedCustomer.getPhone());

         Customer savedCustomer = customerRepository.save(customer);
         return mapper.toDto(customer);
    }

    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }
}