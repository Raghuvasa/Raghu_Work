package com.bmsauth.virt.exceptionHandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.bmsauth.virt.exception.CustomerNotFoundException;
import com.bmsauth.virt.model.ApiResponse;

@RestControllerAdvice
public class CustomerExceptionHandler {

	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<ApiResponse> handleCustomerException(CustomerNotFoundException ex) {

		ApiResponse response = ApiResponse.builder().errorCode(101).message(ex.getMessage()).build();

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	}
}
