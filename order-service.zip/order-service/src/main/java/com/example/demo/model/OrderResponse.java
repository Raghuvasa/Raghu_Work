package com.example.demo.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderResponse {

    private Long orderId;
    private String productName;
    private Double price;
    private CustomerDto customer;
}