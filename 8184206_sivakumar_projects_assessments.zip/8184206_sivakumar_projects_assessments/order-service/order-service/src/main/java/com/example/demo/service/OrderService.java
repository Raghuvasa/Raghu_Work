package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.client.CustomerFeignClients;
import com.example.demo.entity.Order;
import com.example.demo.model.CustomerDto;
import com.example.demo.model.OrderResponse;
import com.example.demo.repo.OrderRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final CustomerFeignClients customerFeignClient;

    public OrderResponse createOrder(Order order) {

        CustomerDto customer = customerFeignClient
                .getCustomerById(order.getCustomerId());

        if (customer == null) {
            throw new RuntimeException("Customer not found");
        }

        Order savedOrder = orderRepository.save(order);

        return OrderResponse.builder()
                .orderId(savedOrder.getId())
                .productName(savedOrder.getProductName())
                .price(savedOrder.getPrice())
                .customer(customer)
                .build();
    }

    public OrderResponse getOrderById(Long id) {

        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        CustomerDto customer = customerFeignClient
                .getCustomerById(order.getCustomerId());

        return OrderResponse.builder()
                .orderId(order.getId())
                .productName(order.getProductName())
                .price(order.getPrice())
                .customer(customer)
                .build();
    }
}