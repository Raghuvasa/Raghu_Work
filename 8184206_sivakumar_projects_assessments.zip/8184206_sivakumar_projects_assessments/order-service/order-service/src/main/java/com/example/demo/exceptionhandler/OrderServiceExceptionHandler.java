package com.example.demo.exceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.demo.exception.OrderServiceException;
import com.example.demo.model.ApiResponse;

@RestControllerAdvice
public class OrderServiceExceptionHandler {

	@ExceptionHandler(OrderServiceException.class)
	public ResponseEntity<ApiResponse> handleOrderServiceException(OrderServiceException ex){
		
		
		ApiResponse response = ApiResponse.builder().errorCode(104).message(ex.getMessage()).build();

		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	}
}
