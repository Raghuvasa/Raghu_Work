package com.bmsauth.virt.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bmsauth.virt.entities.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long>{

}
