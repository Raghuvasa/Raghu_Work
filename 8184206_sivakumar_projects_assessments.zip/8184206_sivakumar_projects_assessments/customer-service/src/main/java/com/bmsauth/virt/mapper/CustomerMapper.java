package com.bmsauth.virt.mapper;

import java.util.List;
import java.util.stream.Collectors;

import com.bmsauth.virt.dto.CustomerDto;
import com.bmsauth.virt.entities.Customer;

public class CustomerMapper {

    public static Customer toEntity(CustomerDto dto) {

        if (dto == null) {
            return null;
        }

        Customer customer = new Customer();
        customer.setName(dto.getName());
        customer.setEmail(dto.getEmail());
        customer.setPhone(dto.getPhone());

        return customer;
    }

    public static CustomerDto toDto(Customer entity) {

        if (entity == null) {
            return null;
        }

        return new CustomerDto(
                entity.getName(),
                entity.getEmail(),
                entity.getPhone()
        );
    }

    public static List<CustomerDto> toDtoList(List<Customer> customers) {

        return customers.stream()
                .map(CustomerMapper::toDto)
                .collect(Collectors.toList());
    }
}