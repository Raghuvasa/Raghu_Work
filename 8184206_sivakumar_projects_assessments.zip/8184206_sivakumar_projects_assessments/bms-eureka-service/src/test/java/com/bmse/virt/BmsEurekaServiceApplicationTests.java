package com.bmse.virt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BmsEurekaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
